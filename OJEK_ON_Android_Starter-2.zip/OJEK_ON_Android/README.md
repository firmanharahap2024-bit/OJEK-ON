# OJEK ON — Android starter project

Proyek awal Android native (Kotlin) untuk OJEK ON, layanan motor antar-jemput penumpang dan barang di wilayah Gunung Tua, Kabupaten Padang Lawas Utara.

## Isi versi 0.1.0
- Pilihan layanan Ojek Penumpang / Ojek Barang
- Kolom lokasi jemput dan tujuan
- Keterangan barang untuk layanan kurir
- Pilihan pembayaran tunai atau transfer/e-wallet
- Ringkasan pesanan simulasi

## Yang belum tersedia
Versi ini belum mengirim order ke driver, belum memiliki akun/login, database/server, GPS/peta, tarif otomatis, notifikasi, dashboard admin, atau pembayaran digital sungguhan. Jangan gunakan untuk menerima pesanan publik sebelum fitur-fitur tersebut dibangun dan diuji.

## Cara membuka
1. Instal Android Studio versi stabil.
2. Pilih **Open** lalu pilih folder `OJEK_ON_Android`.
3. Tunggu Gradle Sync selesai.
4. Sambungkan HP Android dengan USB debugging aktif atau gunakan emulator.
5. Tekan **Run** untuk memasang prototipe.

Untuk membuat APK:
1. Di Android Studio pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Identitas aplikasi
- Nama: OJEK ON
- Application ID: `com.ojekon.app`
- Versi: `0.1.0`
- Minimum Android: Android 6.0 (API 23)


## Build APK memakai HP saja (GitHub Actions)
Folder `.github/workflows/build-apk.yml` berisi alur build otomatis di cloud.

1. Buat akun atau masuk di https://github.com lewat Chrome.
2. Buat repository baru bernama `ojek-on-android` (boleh Public atau Private).
3. Ekstrak ZIP ini menggunakan aplikasi pengelola file di HP.
4. Di halaman repository, pilih **Add file > Upload files**, lalu unggah isi folder proyek (termasuk folder `.github`).
5. Tekan **Commit changes**. GitHub Actions akan menjalankan build.
6. Buka tab **Actions**, pilih workflow **Build OJEK ON APK**, lalu buka hasil run yang sukses.
7. Di bagian **Artifacts**, unduh `OJEK-ON-debug-apk` dan ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

Jika unggah folder tersembunyi `.github` dari HP sulit, buat file melalui GitHub dengan jalur:
`.github/workflows/build-apk.yml`
lalu salin isi file workflow tersebut.

Catatan: Build cloud memerlukan koneksi internet dan akun GitHub. APK debug cocok untuk uji coba, bukan rilis produksi. Fitur server, driver, GPS, tarif dan pembayaran langsung masih belum tersedia.
