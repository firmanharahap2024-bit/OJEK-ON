package com.ojekon.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val green = Color.rgb(8, 125, 53)
    private val paleGreen = Color.rgb(232, 246, 236)
    private var selectedService = "Ojek Penumpang"
    private lateinit var pickup: EditText
    private lateinit var destination: EditText
    private lateinit var itemDetails: EditText
    private lateinit var payment: Spinner
    private lateinit var detailsLabel: TextView
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = green
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showHome() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(248, 250, 248))
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }
        scroll.addView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(green)
        }
        header.addView(label("OJEK ON", 30, Color.WHITE, true))
        header.addView(label("Antar Cepat, Aman dan Terpercaya", 14, Color.WHITE))
        header.addView(label("Gunung Tua • Padang Lawas Utara", 13, Color.WHITE))
        page.addView(header, matchWrap())

        page.addView(space(18))
        page.addView(label("Mau pesan layanan apa?", 21, Color.BLACK, true))
        page.addView(space(10))

        val services = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val passenger = actionButton("🏍  Ojek Penumpang")
        val parcel = actionButton("📦  Ojek Barang")
        passenger.setOnClickListener { selectedService = "Ojek Penumpang"; updateServiceButtons(passenger, parcel) }
        parcel.setOnClickListener { selectedService = "Ojek Barang"; updateServiceButtons(passenger, parcel) }
        services.addView(passenger, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(6) })
        services.addView(parcel, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(6) })
        page.addView(services)
        updateServiceButtons(passenger, parcel)

        page.addView(space(18))
        page.addView(label("Lokasi penjemputan", 14, Color.DKGRAY, true))
        pickup = edit("Contoh: Pasar Gunung Tua")
        page.addView(pickup, matchWrap())
        page.addView(space(12))
        page.addView(label("Lokasi tujuan", 14, Color.DKGRAY, true))
        destination = edit("Masukkan desa atau alamat tujuan")
        page.addView(destination, matchWrap())

        detailsLabel = label("Keterangan barang", 14, Color.DKGRAY, true)
        itemDetails = edit("Contoh: dokumen atau paket kecil")
        page.addView(space(10))
        page.addView(detailsLabel)
        page.addView(itemDetails, matchWrap())
        setParcelVisibility()

        page.addView(space(16))
        page.addView(label("Metode pembayaran", 14, Color.DKGRAY, true))
        payment = Spinner(this)
        val choices = arrayOf("Tunai — bayar langsung ke driver", "Transfer / E-Wallet")
        payment.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        page.addView(payment, matchWrap())

        page.addView(space(18))
        val order = actionButton("PESAN OJEK ON")
        order.setTextColor(Color.WHITE)
        order.setBackgroundColor(green)
        order.setOnClickListener { createDemoOrder() }
        page.addView(order, LinearLayout.LayoutParams(-1, dp(54)))

        result = label("", 14, green)
        result.setPadding(dp(12), dp(12), dp(12), dp(12))
        page.addView(result, matchWrap())

        page.addView(space(18))
        page.addView(label("Layanan OJEK ON", 18, green, true))
        page.addView(label("• Antar jemput penumpang\n• Antar jemput barang\n• Melayani wilayah desa-desa sesuai jangkauan operasional\n• Pembayaran tunai atau transfer", 14, Color.DKGRAY))
        page.addView(space(18))
        page.addView(label("Catatan: versi awal ini adalah prototipe. Pesanan belum dikirim ke driver dan belum memakai GPS, peta, server, atau pembayaran sungguhan.", 12, Color.GRAY))
        setContentView(scroll)
    }

    private fun setParcelVisibility() {
        val visible = selectedService == "Ojek Barang"
        detailsLabel.visibility = if (visible) View.VISIBLE else View.GONE
        itemDetails.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun updateServiceButtons(passenger: Button, parcel: Button) {
        passenger.setBackgroundColor(if (selectedService == "Ojek Penumpang") paleGreen else Color.WHITE)
        parcel.setBackgroundColor(if (selectedService == "Ojek Barang") paleGreen else Color.WHITE)
        passenger.setTextColor(green)
        parcel.setTextColor(green)
        if (::detailsLabel.isInitialized) setParcelVisibility()
    }

    private fun createDemoOrder() {
        val from = pickup.text.toString().trim()
        val to = destination.text.toString().trim()
        if (from.isEmpty() || to.isEmpty()) {
            Toast.makeText(this, "Isi lokasi jemput dan tujuan terlebih dahulu.", Toast.LENGTH_LONG).show()
            return
        }
        if (selectedService == "Ojek Barang" && itemDetails.text.toString().trim().isEmpty()) {
            Toast.makeText(this, "Isi keterangan barang terlebih dahulu.", Toast.LENGTH_LONG).show()
            return
        }
        val pay = if (payment.selectedItemPosition == 0) "Tunai" else "Transfer / E-Wallet"
        val extra = if (selectedService == "Ojek Barang") "\nBarang: ${itemDetails.text}" else ""
        result.text = "SIMULASI PESANAN\nLayanan: $selectedService\nJemput: $from\nTujuan: $to$extra\nPembayaran: $pay\n\nBelum ada driver yang menerima pesanan."
        result.setBackgroundColor(paleGreen)
        Toast.makeText(this, "Simulasi pesanan berhasil dibuat.", Toast.LENGTH_SHORT).show()
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun edit(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine(true)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(Color.WHITE)
    }

    private fun actionButton(textValue: String) = Button(this).apply {
        text = textValue
        textSize = 13f
        isAllCaps = false
        setTextColor(green)
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
